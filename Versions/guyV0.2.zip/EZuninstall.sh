sudo rm /usr/local/bin/guy
