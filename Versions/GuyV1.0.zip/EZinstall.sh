sudo cp ./guy /usr/local/bin/
sudo chmod +x /usr/local/bin/guy
